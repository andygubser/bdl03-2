original files are avaiable on https://data.open-power-system-data.org/household_data/2020-04-15

a backup of the original files and the prepared files are available on https://web.tresorit.com/l/tQeWY#E7GFEo5HKmOZA0gLNxUf_g